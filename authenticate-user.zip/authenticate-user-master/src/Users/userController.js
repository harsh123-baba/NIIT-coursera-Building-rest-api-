

//import userService


function findUser(email,done){
    //call userService findUser method and pass the parameters
   
}

module.exports = {
    findUser
}